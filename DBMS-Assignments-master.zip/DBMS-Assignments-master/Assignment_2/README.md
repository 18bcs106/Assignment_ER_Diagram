# DBMS-Assignments
This is the official repository containing all the College DBMS Assignments
